package com.aliangmaker.meida;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.aliangmaker.meida.databinding.ActivityPlaySetBinding;

public class PlaySetActivity extends AppCompatActivity {
    ActivityPlaySetBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPlaySetBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getSupportFragmentManager().registerFragmentLifecycleCallbacks(new FragmentManager.FragmentLifecycleCallbacks() {
            @Override
            public void onFragmentViewCreated(@NonNull FragmentManager fm, @NonNull Fragment f, @NonNull View v, @Nullable Bundle savedInstanceState) {
                super.onFragmentViewCreated(fm, f, v, savedInstanceState);
                if (f instanceof BaseTitleFragment) {
                    ((BaseTitleFragment) f).setTextViewText("播放设置");
                }
            }
        }, false);
        SharedPreferences sharedPreferences = getSharedPreferences("play_set", MODE_PRIVATE);
        if (sharedPreferences.getBoolean("hard_play", true)) {
            binding.pr2.setChecked(true);
            binding.pr1.setChecked(false);
        } else {
            binding.pr2.setChecked(false);
            binding.pr1.setChecked(true);
        }
        binding.rg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.pr2)   sharedPreferences.edit().putBoolean("hard_play", true).apply();
            else   sharedPreferences.edit().putBoolean("hard_play", false).apply();
        });
        if (sharedPreferences.getBoolean("jump_play", false)) {
            binding.jumpSwitch.setChecked(true);
        }else binding.jumpSwitch.setChecked(false);
        binding.jumpSwitch.setOnClickListener(v -> sharedPreferences.edit().putBoolean("jump_play", binding.jumpSwitch.isChecked()).apply());
    }
}