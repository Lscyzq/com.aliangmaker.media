package com.aliangmaker.meida;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.aliangmaker.meida.databinding.ActivityErrorBackBinding;
import com.aliangmaker.meida.databinding.ActivitySingleTouchBinding;
import com.aliangmaker.meida.databinding.ActivityVersionUpBinding;

public class EmptyActivity extends AppCompatActivity {
    private ActivitySingleTouchBinding binding;
    private ActivityVersionUpBinding bindingVersion;

    private void setSPSet(String item) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(EmptyActivity.this);
        if (item.equals("0")) {
            sharedPreferences.edit().putBoolean("single_touch",true).apply();
        }
    }
    String layout;
    private void setTitleText (String text){
        getSupportFragmentManager().registerFragmentLifecycleCallbacks(new FragmentManager.FragmentLifecycleCallbacks() {
            @Override
            public void onFragmentViewCreated(@NonNull FragmentManager fm, @NonNull Fragment f, @NonNull View v, @Nullable Bundle savedInstanceState) {
                super.onFragmentViewCreated(fm, f, v, savedInstanceState);
                if(f instanceof BaseTitleFragment){
                    ((BaseTitleFragment)f).setTextViewText(text);

                }
            }
        }, false);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        layout = getIntent().getStringExtra("layout");
        if (layout.equals("activity_privacy_policy")) {
            setContentView(R.layout.activity_privacy_policy);
            setTitleText("隐私条款");
        } else if (layout.equals("activity_up_log")) {
            setContentView(R.layout.activity_up_log);
            setTitleText("更新日志");
        } else if (layout.equals("activity_aliang_unique")) {
            setContentView(R.layout.activity_aliang_unique);
            setTitleText("作者的话");
        } else if (layout.equals("activity_allowance")) {
            setContentView(R.layout.activity_allowance);
            setTitleText("赞助我们");
        } else if (layout.equals("activity_error_back")) {
            setContentView(R.layout.activity_error_back);
            setTitleText("建议反馈");
        } else if (layout.equals("activity_single_touch")) {
            binding = ActivitySingleTouchBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());
            setSPSet("0");
            setTitleText("单指说明");
        } else if (layout.equals("activity_update")) {
            bindingVersion = ActivityVersionUpBinding.inflate(getLayoutInflater());
            setContentView(bindingVersion.getRoot());
            setTitleText("更新指引");
            bindingVersion.textView42.setText(getIntent().getStringExtra("upLog")+"\n建议你通过洋葱商店进行更新以体验最新版（其他商店审核需要时间）或者你也可以访问下方链接直接进行下载（长按以复制）：\n\n密码:aypi\nhttps://wwtv.lanzoui.com/b048jfjpg");
            bindingVersion.textView42.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    CharSequence text = "https://wwtv.lanzoui.com/b048jfjpg";
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clipData = ClipData.newPlainText("text", text);
                    clipboardManager.setPrimaryClip(clipData);
                    Toast.makeText(EmptyActivity.this, "已复制链接！", Toast.LENGTH_SHORT).show();
                    return true;
                }
            });
            if (getIntent().getStringExtra("visible").equals("null")) {
                bindingVersion.checkBox.setVisibility(View.GONE);
            } else {
                bindingVersion.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        SharedPreferences sharedPreferences = getSharedPreferences("ifCheck", MODE_PRIVATE);
                        if (isChecked) {
                            sharedPreferences.edit().putString("Version", getIntent().getStringExtra("versionCheck")).apply();
                        } else
                            sharedPreferences.edit().putString("Version", getString(R.string.version)).apply();
                    }
                });
            }
        } else if (layout.equals("github")) {
            ActivityErrorBackBinding bindingGithub;
            bindingGithub = ActivityErrorBackBinding.inflate(getLayoutInflater());
            setContentView(bindingGithub.getRoot());
            bindingGithub.imageView12.setImageResource(R.drawable.github);
            bindingGithub.textView27.setText("https://lscyzq.github.io/access/com.aliangmaker.media.txt");
            bindingGithub.textView27.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    CharSequence text = "https://lscyzq.github.io/access/com.aliangmaker.media.txt";
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clipData = ClipData.newPlainText("text", text);
                    clipboardManager.setPrimaryClip(clipData);
                    Toast.makeText(EmptyActivity.this, "已复制链接！", Toast.LENGTH_SHORT).show();
                    return true;
                }
            });
            bindingGithub.textView28.setText("请通过其他设备扫描上方二维码打开或者长按二维码下方链接进行复制");
            bindingGithub.textView33.setVisibility(View.GONE);
            bindingGithub.textView32.setVisibility(View.GONE);
            setTitleText("接入指引");
        }else if (layout.equals("activity_notice")) {
            bindingVersion = ActivityVersionUpBinding.inflate(getLayoutInflater());
            setContentView(bindingVersion.getRoot());
            setTitleText("重要公告");
            bindingVersion.checkBox.setVisibility(View.GONE);
            bindingVersion.imageView14.setVisibility(View.GONE);
            bindingVersion.textView42.setText(getIntent().getStringExtra("notice"));
        }
    }
}